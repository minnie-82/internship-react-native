#include<bits/stdc++.h>
#define fastio ios_base::sync_with_stdio(false); cin.tie(NULL);
using namespace std;


int main(){
    fastio;

    freopen("TESTCASES/INPUT/input10.txt","w",stdout); 
    
    int t = 46;
    cout << t << "\n";

    while(t--){

        int m=(rand() % 10000)+1;

        int n = (rand() % 1000)+ 1;
        cout <<m<<" "<<n<< "\n";

        for(int i=0;i<n;i++)
      {
          int x=(rand()% 10000) +1;
          int y=(rand()% 10000) +1;
          cout<<x<<" "<<y<<"\n";
      }
        
    }//end of test case loop
    return 0;
}