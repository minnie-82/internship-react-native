#include <bits/stdc++.h>
#define ll long long int
#define vi vector<ll>
#define vop vector<pair<ll, ll>>
using namespace std;
 
void file_i_o()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
}
 
int main()
{
    file_i_o();
     freopen("TESTCASES/INPUT/input10.txt","r",stdin);
    freopen("TESTCASES/OUTPUT/output10.txt","w",stdout);
    ll t;
    cin>>t;
    while(t--)
    {
    ll s, n;
    cin >> s >> n;
    vop v;
    for (int i = 0; i < n; i++)
    {
        ll a, b;
        cin >> a >> b;
        v.push_back({a, b});
    }
    sort(v.begin(), v.end());
    string ans = "YES";
    for (int i = 0; i < n; i++)
    {
        if (s > v[i].first)
        {
            s += v[i].second;
        }
        else if (s == v[i].first)
        {
            s -= v[i].first;
            if(s==0)
            {
                ans="NO";
                break;
            }
            s += v[i].second;
        }
        else
        {
            ans = "NO";
            break;
        }
    }
    cout << ans<<endl;
    }
    return 0;
}